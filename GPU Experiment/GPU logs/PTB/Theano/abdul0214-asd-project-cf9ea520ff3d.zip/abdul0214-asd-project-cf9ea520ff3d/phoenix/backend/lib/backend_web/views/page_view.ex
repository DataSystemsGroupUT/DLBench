defmodule BackendWeb.PageView do
  use BackendWeb, :view
end
