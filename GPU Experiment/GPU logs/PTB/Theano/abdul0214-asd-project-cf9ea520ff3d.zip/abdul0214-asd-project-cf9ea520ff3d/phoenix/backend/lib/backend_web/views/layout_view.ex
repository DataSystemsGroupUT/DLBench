defmodule BackendWeb.LayoutView do
  use BackendWeb, :view
end
