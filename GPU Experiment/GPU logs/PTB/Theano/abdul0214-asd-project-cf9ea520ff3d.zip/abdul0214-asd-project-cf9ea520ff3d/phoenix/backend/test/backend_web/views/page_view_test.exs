defmodule BackendWeb.PageViewTest do
  use BackendWeb.ConnCase, async: true
end
