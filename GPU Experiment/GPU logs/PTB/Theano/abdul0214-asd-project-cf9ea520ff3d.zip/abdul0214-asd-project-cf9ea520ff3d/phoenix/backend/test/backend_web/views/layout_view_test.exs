defmodule BackendWeb.LayoutViewTest do
  use BackendWeb.ConnCase, async: true
end
